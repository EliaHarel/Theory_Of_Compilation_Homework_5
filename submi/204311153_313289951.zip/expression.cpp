//
// Created by EliaHarel on 16/01/2021.
//

#include "expression.h"

int Expression::new_var_counter = 0;