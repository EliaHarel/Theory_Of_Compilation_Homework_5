//
// Created by Daniel Yacoby on 21/01/2021.
//

#include "var.h"

int Var::new_var_counter = 0;