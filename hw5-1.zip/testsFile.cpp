//
// Created by EliaHarel on 17/01/2021.
//

#include "expression.h"
#include "iostream"

void testsFunctionMain(){
    Expression var();
    std::cout << Expression::gimmeANewCuteVar() << std::endl;
    std::cout << Expression::gimmeANewCuteVar() << std::endl;
    std::cout << Expression::gimmeANewCuteVar() << std::endl;

}