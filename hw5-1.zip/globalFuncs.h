//
// Created by EliaHarel on 24/12/2020.
//

#ifndef PROJECT_GLOBALFUNCS_H
#define PROJECT_GLOBALFUNCS_H

#include <string>
#include "enums.h"

std::string enumToString(Types type);


Types setCheck(int, int, int);

void printGlobalFuncs();


#endif //PROJECT_GLOBALFUNCS_H
